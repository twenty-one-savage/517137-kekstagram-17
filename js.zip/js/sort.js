'use strict';
// Зависит от load.js и render.js
// sort module
// Сортировка фотографий
(function () {
  var imgFiltersElement = document.querySelector('.img-filters');
  var imgFiltersNewElement = document.querySelector('#filter-new');

  // Сортировка фотографий по новым
  var sortByNew = function (data) {

  };

  imgFiltersNewElement.addEventListener('click', sortByNew);

  window.sort = {
    imgFiltersElement: imgFiltersElement
  };
})();
