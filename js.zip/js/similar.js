'use strict';
// Зависит от render.js,load.js,sort.js
// similar module
(function () {
  var photos = [];
  var successHandler = function (data) {
    photos = data;
    window.render(photos);
    window.sort.imgFiltersElement.classList.remove('img-filters--inactive');
  };

  var errorHandler = function (errorMessage) {
    var node = document.createElement('div');
    node.style = 'z-index: 100; margin: 0 auto; text-align: center; background-color: red;';
    node.style.position = 'absolute';
    node.style.left = 0;
    node.style.right = 0;
    node.style.fontSize = '30px';

    node.textContent = errorMessage;
    document.body.insertAdjacentElement('afterbegin', node);
  };
  window.load(successHandler, errorHandler);
})();
